# fileWrangling
Space for collecting scripts used to analyze, organize, and reformat files and file systems in preparation for deposit to preservation digital repostiory.
